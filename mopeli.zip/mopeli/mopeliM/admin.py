from django.contrib import admin
from mopeliM.models import TipoCatastrofe, Catastrofe
from django.contrib.admin import ModelAdmin



class ListaFiltro(admin.ModelAdmin):
    
    list_display = ['categoria', 'ruaPontoReferencia','bairro', 'dataAcidente']
    list_filter = ('id', 'categoria')


# Register your models here.
admin.site.register(Catastrofe,  ListaFiltro)
admin.site.register(TipoCatastrofe)

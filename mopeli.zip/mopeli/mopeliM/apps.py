from django.apps import AppConfig


class MopelimConfig(AppConfig):
    name = 'mopeliM'

from django import forms
from django.forms import ModelForm
from mopeliM.models import Catastrofe 

class CatastrofeForm(forms.ModelForm):

    nome = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder':'entre com o nome'}))
    
    class Meta:
        model = Catastrofe
        fields = '__all__'



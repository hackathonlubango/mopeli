from django.db import models
# Create your models here.


class TipoCatastrofe(models.Model):
    tipoCatastrofe = models.CharField(verbose_name = 'Tipo/Catastrofe', max_length=50)
    
    class Meta:
        ordering =['tipoCatastrofe']
        verbose_name = 'tipo Catastrofe'
        verbose_name_plural = 'tipos Catastrofes'

    def __str__(self):
        return self.tipoacidente

class Catastrofe (models.Model):
    tipoCatastrofe = models.ForeignKey(TipoCatastrofe, on_delete=models.CASCADE)
    categoria = models.CharField(verbose_name = 'Categoria', max_length=50)
    ruaPontoReferencia = models.CharField(verbose_name = 'Rua/Referencia', max_length=50)
    bairro = models.CharField(verbose_name = 'Bairro', max_length=100)
    dataAcidente = models.DateTimeField(u'Acontecimento')

    class Meta:
        ordering =['-dataAcidente']
        verbose_name = 'Catastrofe'
        verbose_name_plural = 'Catastrofes'

    def __str__(self):
        return self.categoria
    




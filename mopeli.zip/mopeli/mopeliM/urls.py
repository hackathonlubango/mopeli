
from django.urls import path
from . import views

urlpatterns = [

    path('', views.Home.as_view(), name='home'),  
    #path('sob', views.Sobre.as_view(), name='sobre'),
    path('yhtgcrfed', views.cadastroAcidente, name='pagina'),
    #path('contact', views.Contacto.as_view(), name='contacto'),
    #path('delete/<int:id>', views.delete, name='delete'),
    path('edit/<int:id>', views.edit, name='editar')
    
    
]
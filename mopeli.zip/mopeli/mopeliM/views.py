from django.shortcuts import render
from mopeliM.models import Catastrofe
from mopeliM.forms import CatastrofeForm
from django.views.generic import View, TemplateView, ListView
from django.views.generic import CreateView, ListView, DetailView


# Create your views here.
class Home(ListView):   
    queryset = Catastrofe.objects.all() #.order_by('-publication_date')
    context_object_name = 'listaTarefa'
    template_name = 'mopeliM/index.html'

def cadastroAcidente(request):
    if request.method == 'POST':
        form = CatastrofeForm(request.POST)
        if form.is_valid():
             
            form.save()
            return HttpResponseRedirect(reverse_lazy('pagina'))
    form = CatastrofeForm
    context = {}
    template_name = 'mopeliM/acidente.html'
    return render(request, template_name, {'form':form})

def edit(request, id):
   context = {}
   template_name ='mopeliM/edit.html'
   obj = get_object_or_404(Catastrofe, id = id)
   form = TarefaForm(request.POST or None, instance = obj)
   if form.is_valid():
       form.save()
       return HttpResponseRedirect( reverse_lazy('sobre'))
   context= {'form': form }
   return render(request, template_name, context)